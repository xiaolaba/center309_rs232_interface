Software for the HH309 Digital Thermometer (SE309.zip). This is for customers who purchase the unit and lost the software.

Windows 98,NT,XP,ME.  
Version 2.2.0.0 
